// Beginner-friendly local server. Visits are disclosed on the portfolio;
// detailed logs are available only on the password-protected /owner page.
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const root = __dirname;
const logPath = path.join(root, "visits.jsonl");
const mime = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".txt": "text/plain; charset=utf-8", ".svg": "image/svg+xml", ".pdf": "application/pdf", ".jpeg": "image/jpeg", ".jpg": "image/jpeg", ".png": "image/png" };

function readVisits() {
  try {
    return fs.readFileSync(logPath, "utf8").split("\n").filter(Boolean)
      .map(line => { try { return JSON.parse(line); } catch { return null; } })
      .filter(Boolean).slice(-200).reverse();
  } catch { return []; }
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}
function ownerAuthorized(req, res) {
  const password = process.env.OWNER_PASSWORD;
  if (!password) {
    res.writeHead(503, { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" });
    res.end("Owner dashboard is disabled. Set the OWNER_PASSWORD environment variable, then restart the server.");
    return false;
  }
  const expected = "Basic " + Buffer.from("owner:" + password).toString("base64");
  const actual = req.headers.authorization || "";
  const expectedBytes = Buffer.from(expected);
  const actualBytes = Buffer.from(actual);
  const matches = expectedBytes.length === actualBytes.length && crypto.timingSafeEqual(expectedBytes, actualBytes);
  if (!matches) {
    res.writeHead(401, { "WWW-Authenticate": 'Basic realm="Portfolio owner", charset="UTF-8"', "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" });
    res.end("Sign in with username owner and your configured owner password.");
    return false;
  }
  return true;
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");
  if (url.pathname === "/owner") {
    if (!ownerAuthorized(req, res)) return;
    const entries = readVisits();
    const rows = entries.map(entry => `<tr><td>${escapeHtml(entry.time)}</td><td>${escapeHtml(entry.ip)}</td><td>${escapeHtml(entry.path)}</td><td>${escapeHtml(entry.userAgent)}</td></tr>`).join("");
    const page = `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Portfolio visits</title><style>*{box-sizing:border-box}body{margin:0;background:#0b1020;color:#f8fafc;font:16px/1.6 system-ui,sans-serif}main{width:min(1100px,calc(100% - 36px));margin:56px auto}h1{font-size:clamp(2rem,5vw,3.5rem);letter-spacing:-.05em;margin:0}p{color:#aab5c7}.note{padding:16px 18px;border:1px solid #8b5cf655;border-radius:12px;background:#8b5cf611}a{color:#c4b5fd}.table-wrap{overflow:auto;margin-top:24px;border:1px solid #ffffff24;border-radius:12px}table{width:100%;border-collapse:collapse;min-width:760px}th,td{text-align:left;padding:13px 15px;border-bottom:1px solid #ffffff18;vertical-align:top}th{color:#c4b5fd;background:#ffffff08}td{color:#dbe4f0;font-size:.9rem;overflow-wrap:anywhere}tr:last-child td{border-bottom:0}.empty{padding:28px;color:#aab5c7}</style><main><p>PRIVATE OWNER DASHBOARD</p><h1>Portfolio visits</h1><p>This list shows the latest ${entries.length} logged page visits (up to 200). IP addresses and browser details may be shared or misleading; they do not identify a person.</p><div class="note">Visitors are told that the server records the IP address it receives, visit time, page, and browser user-agent. Keep this log private and delete it when you no longer need it. A visitor’s name is available only if they choose to identify themselves.</div><div class="table-wrap"><table><thead><tr><th>Time (UTC)</th><th>IP received by server</th><th>Page</th><th>Browser details</th></tr></thead><tbody>${rows || '<tr><td class="empty" colspan="4">No visits recorded yet.</td></tr>'}</tbody></table></div><p><a href="/">← Back to portfolio</a></p></main></html>`;
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
    res.end(page);
    return;
  }
  if (url.pathname === "/api/visit") {
    // Do not trust forwarded headers unless deployed behind a proxy you control.
    const ip = req.socket.remoteAddress || "Not provided";
    const entry = {
      ip,
      time: new Date().toISOString(),
      path: url.searchParams.get("page") || "/",
      userAgent: req.headers["user-agent"] || "Not provided"
    };
    fs.appendFile(logPath, JSON.stringify(entry) + "\n", err => {
      if (err) console.error("Could not save visit log:", err.message);
    });
    res.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
    res.end(JSON.stringify({ recorded: true }));
    return;
  }
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === "/") pathname = "/index.html";
  const file = path.resolve(root, "." + pathname);
  if (!file.startsWith(root + path.sep) && file !== path.join(root, "index.html")) {
    res.writeHead(403); res.end("Forbidden"); return;
  }
  fs.readFile(file, (err, body) => {
    if (err) { res.writeHead(404); res.end("Not found"); return; }
    res.writeHead(200, { "Content-Type": mime[path.extname(file)] || "application/octet-stream" });
    res.end(body);
  });
});
const firstPort = Number(process.env.PORT) || 3000;
function listenOnAvailablePort(port) {
  server.once("error", error => {
    if (error.code === "EADDRINUSE" && port < firstPort + 20) {
      console.log(`Port ${port} is busy; trying ${port + 1}...`);
      listenOnAvailablePort(port + 1);
      return;
    }
    console.error("Could not start the portfolio server:", error.message);
    process.exitCode = 1;
  });
  server.listen(port, () => console.log(`Portfolio running at http://localhost:${port}`));
}
listenOnAvailablePort(firstPort);
